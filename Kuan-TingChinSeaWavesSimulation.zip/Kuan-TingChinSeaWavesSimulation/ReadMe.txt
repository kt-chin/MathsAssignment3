Folder contains Unity Executable.

Youtube video:
https://youtu.be/UOklxbRU0bQ

Controls:

W/A/S/D: Movement
E/Q: Scroll High/Low
T : Enable/Disable Mouse Cursor/Look Around
Left Click : Fire Buoyancy Cubes
X: Delete Fired Buoyancy Cubes
Esc: Quit Application